/* Huincha — análisis de fotos con IA (Claude).
   En la vista previa dentro de Claude usa la capacidad "sample" de la página.
   En la app instalada usa la API de Anthropic con una clave que el usuario guarda en su equipo (pago por uso). */
"use strict";
const IA=(()=>{let ns;const KEY='huincha.iakey',MODEL='claude-sonnet-5-5';
  async function sampleNS(){if(ns!==undefined)return ns;ns=null;try{const s=await window.claude?.use?.('sample');if(s){const lim=await s.limits().catch(()=>null);if(lim&&lim.images)ns=s}}catch(e){ns=null}return ns}
  const key=()=>{try{return localStorage.getItem(KEY)||''}catch(e){return''}};
  function setKey(k){try{k?localStorage.setItem(KEY,k):localStorage.removeItem(KEY)}catch(e){}}
  async function mode(){if(await sampleNS())return'claude';if(key())return'api';return null}
  const keys=cat=>Object.keys(MATS[cat].opts).join(', ');
  function prompt(ctx){return`Eres el asistente de una app chilena de levantamiento de viviendas. Analiza la foto adjunta.
Contexto del levantamiento: ${ctx}
Responde SOLO con un objeto JSON, sin texto adicional, con esta forma:
{"descripcion":"una o dos frases de lo que se ve",
 "elementos":[{"tipo":"puerta|ventana|puerta-ventana|escalera|pilotes|baranda|otro","detalle":"texto breve"}],
 "volumenes":[{"tipo":"domo|segundo|ampliacion|terraza|cobertizo|otro","forma":"circulo|rect","detalle":"qué es y dónde está respecto de la casa"}],
 "materiales":{"revExt":null,"cubierta":null,"ventanas":null,"zocalo":null,"estructura":null},
 "preguntas":["preguntas concretas que el usuario debe responder en terreno para completar planos y 3D (máximo 4)"]}
Claves válidas para materiales (usa null si no se distingue): revExt: ${keys('revExt')}; cubierta: ${keys('cubierta')}; ventanas: ${keys('ventanas')}; zocalo: ${keys('zocalo')}; estructura: ${keys('estructura')}.
En "volumenes" incluye solo construcciones fuera del contorno rectangular de la casa (domos, segundos pisos o altillos, estructuras sobre pilotes, terrazas, ampliaciones, quinchos).
No inventes medidas. Si estimas una dimensión, dilo como estimación dentro de "detalle". Escribe en español de Chile.`}
  async function analyze(blob,ctx){const m=await mode();if(!m)throw Object.assign(new Error('Sin IA configurada'),{code:'sin-ia'});
    if(m==='claude'){const s=await sampleNS();return clean(await s.json(prompt(ctx),{images:[blob],modelTier:'default'}))}
    const b64=await Store.toB64(blob);
    const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':key(),'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
      body:JSON.stringify({model:MODEL,max_tokens:1500,messages:[{role:'user',content:[{type:'image',source:{type:'base64',media_type:blob.type||'image/jpeg',data:b64}},{type:'text',text:prompt(ctx)}]}]})});
    if(!r.ok)throw Object.assign(new Error('La API respondió '+r.status),{code:r.status===401?'clave':'api'});
    const j=await r.json();const t=(j.content||[]).map(c=>c.text||'').join('');const mm=t.match(/\{[\s\S]*\}/);return clean(JSON.parse(mm?mm[0]:t))}
  function clean(o){o=o||{};const mat={};for(const [k,v] of Object.entries(o.materiales||{}))if(v&&MATS[k]?.opts[v])mat[k]=v;
    return{descripcion:String(o.descripcion||''),elementos:Array.isArray(o.elementos)?o.elementos.slice(0,12):[],volumenes:(Array.isArray(o.volumenes)?o.volumenes:[]).filter(v=>VOLT[v.tipo]).slice(0,4),materiales:mat,preguntas:(Array.isArray(o.preguntas)?o.preguntas:[]).map(String).filter(Boolean).slice(0,4)}}
  /* Reconocimiento de elementos en un cuadro del recorrido en vivo.
     Devuelve dónde toca el suelo cada elemento (x, y de 0 a 1 en la imagen) y medidas estimadas. */
  function promptDet(ctx){const tipos=Object.entries(ELT).map(([k,t])=>`${k} (${t.n})`).join(', ');
    return`Eres el asistente de una app chilena que levanta planos de casas y terrenos mientras el usuario camina con la cámara.
Contexto: ${ctx}
Actúa como un arquitecto o constructor con experiencia en viviendas chilenas (urbanas, de condominio y parcelas rurales).
Primero entiende de qué terreno se trata (tipo de propiedad, pendiente, cómo se organiza la casa y el patio). Luego reconoce por su forma, material y función los elementos constructivos y de paisaje que deben ir en el plano.
Ignora siempre lo que no es parte de la construcción ni del terreno: autos, bicicletas, personas, animales, muebles sueltos, herramientas, basura, ropa tendida u objetos temporales.
Responde SOLO con JSON, sin texto adicional:
{"escena":{"terreno":"tipo de terreno en pocas palabras","pendiente":"plano|suave|fuerte","resumen":"una frase con lo esencial del lugar"},
 "objetos":[{"tipo":"clave","nombre":null,"x":0.5,"y":0.8,"dist":4.5,"ancho":3,"largo":2,"alto":1.8,"conf":0.8,"detalle":"material y estado, breve"}],
 "vanos":[{"tipo":"puerta|ventana","x":0.4,"y":0.9,"ancho":0.9,"alto":2.0}],
 "piso":null}
Claves válidas para "tipo" en objetos: ${tipos}.
- "x","y": posición en la imagen (0 = izquierda/arriba, 1 = derecha/abajo) del punto donde el elemento toca el suelo, en su centro. Para cierres (reja, portón, cerco, muro, malla) da el centro del tramo visible y en "ancho" su largo.
- "dist": distancia estimada en metros desde la cámara hasta ese punto. "ancho" y "largo": medidas en planta estimadas; "alto": altura estimada.
- Si un elemento constructivo no calza con ninguna clave (por ejemplo horno de barro, leñera, gallinero, pozo, fogón, muro de contención, canaleta), usa "otro" y pon en "nombre" cómo se llama, en dos o tres palabras.
- Estima las medidas comparando con referencias conocidas: puertas de 2 m de alto, bloques o ladrillos, paños de reja de 2 a 2,5 m, peldaños de 18 cm.
- "vanos": puertas y ventanas en los muros de la casa (no portones de rejas).
- "piso": si se ve el piso de un recinto interior, una de estas claves: ${Object.keys(MATS.piso.opts).join(', ')}; si no, null.
- Incluye como máximo 8 objetos, solo los que se distinguen con claridad, y "conf" entre 0 y 1. No incluyas la casa principal ni personas, autos o muebles sueltos.
Escribe "detalle" en español de Chile.`}
  async function detect(blob,ctx){const m=await mode();if(!m)throw Object.assign(new Error('Sin IA configurada'),{code:'sin-ia'});let o;
    if(m==='claude'){const s=await sampleNS();o=await s.json(promptDet(ctx),{images:[blob],modelTier:'default'})}
    else{const b64=await Store.toB64(blob);
      const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':key(),'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
        body:JSON.stringify({model:MODEL,max_tokens:1200,messages:[{role:'user',content:[{type:'image',source:{type:'base64',media_type:blob.type||'image/jpeg',data:b64}},{type:'text',text:promptDet(ctx)}]}]})});
      if(!r.ok)throw Object.assign(new Error('La API respondió '+r.status),{code:r.status===401?'clave':'api'});
      const j=await r.json();const t=(j.content||[]).map(c=>c.text||'').join('');const mm=t.match(/\{[\s\S]*\}/);o=JSON.parse(mm?mm[0]:t)}
    const n01=v=>Math.max(0,Math.min(1,+v||0)),pos=v=>+v>0?+v:null;
    const es=o?.escena&&typeof o.escena==='object'?{terreno:String(o.escena.terreno||''),pendiente:String(o.escena.pendiente||''),resumen:String(o.escena.resumen||'')}:null;
    return{escena:es,objetos:(Array.isArray(o?.objetos)?o.objetos:[]).filter(x=>ELT[x.tipo]).slice(0,8).map(x=>({tipo:x.tipo,nombre:x.tipo==='otro'&&x.nombre?String(x.nombre).slice(0,40):null,x:n01(x.x??.5),y:n01(x.y??.8),dist:pos(x.dist),ancho:pos(x.ancho),largo:pos(x.largo),alto:pos(x.alto),conf:Math.max(0,Math.min(1,+x.conf||.5)),detalle:String(x.detalle||'')})),
      vanos:(Array.isArray(o?.vanos)?o.vanos:[]).filter(v=>v.tipo==='puerta'||v.tipo==='ventana').slice(0,6).map(v=>({tipo:v.tipo,x:n01(v.x??.5),y:n01(v.y??.9),ancho:pos(v.ancho),alto:pos(v.alto)})),
      piso:MATS.piso.opts[o?.piso]?o.piso:null}}
  return{mode,analyze,detect,key,setKey}})();

/* Contexto breve del proyecto para la IA */
function iaContexto(extra=''){const c=P.casa;return[`casa ${c.ancho>0?fmt(c.ancho)+' × '+fmt(c.largo)+' m':'sin medidas aún'}`,`${P.recintos.length} recintos`,(P.volumenes||[]).length?'volúmenes: '+P.volumenes.map(v=>v.nombre).join(', '):'',extra].filter(Boolean).join('; ')}
/* Resultado del análisis, con acciones para aplicar lo detectado */
function iaResultHTML(r){const M=P.mat;return`<div class="iares"><p><b>La IA ve:</b> ${esc(r.descripcion||'—')}</p>
  ${r.elementos.length?`<div class="chips">${r.elementos.map(e=>`<span class="chip">${esc(e.tipo)}${e.detalle?' · '+esc(e.detalle):''}</span>`).join('')}</div>`:''}
  ${r.volumenes.length?`<div class="fld"><span>Fuera del contorno</span>${r.volumenes.map(v=>`<div class="row sb"><span>${esc(VOLT[v.tipo].n)}${v.detalle?' — '+esc(v.detalle):''}</span><button class="btn sm pri" data-iavol="${v.tipo}:${v.forma==='circulo'?'circulo':'rect'}">Agregar</button></div>`).join('')}</div>`:''}
  ${Object.keys(r.materiales).length?`<div class="fld"><span>Materiales sugeridos</span>${Object.entries(r.materiales).map(([k,v])=>`<div class="row sb"><span>${esc(MATS[k].lab)}: ${esc(mn(k,v))}</span>${M[k]===v?'<span class="lbl">Ya elegido</span>':`<button class="btn sm" data-iamat="${k}:${v}">Aplicar</button>`}</div>`).join('')}</div>`:''}
  ${r.preguntas.length?`<div class="fld"><span>Preguntas para completar</span><ul class="iaq">${r.preguntas.map(q=>`<li>${esc(q)}</li>`).join('')}</ul><small>Quedan anotadas en el asistente.</small></div>`:''}</div>`}
function iaGuardarPreguntas(r,step){for(const q of r.preguntas){if((P.iaPreg||[]).some(x=>x.texto===q))continue;(P.iaPreg=P.iaPreg||[]).push({id:'ia-'+Math.random().toString(36).slice(2,8),texto:q,step:step??1})}persist()}
function iaErrorMsg(e){return e?.code==='sin-ia'?'Para analizar fotos con IA, guarda tu clave de API en el paso Proyecto.':e?.code==='clave'?'La clave de API no es válida. Revísala en el paso Proyecto.':'No se pudo analizar la foto. Revisa la conexión e inténtalo de nuevo.'}
/* Acciones comunes de los resultados */
document.addEventListener('click',e=>{const b=e.target.closest('[data-iamat],[data-iavol]');if(!b)return;const d=b.dataset;
  if(d.iamat){const i=d.iamat.indexOf(':');P.mat[d.iamat.slice(0,i)]=d.iamat.slice(i+1);persist();b.outerHTML='<span class="lbl">Aplicado</span>';toast('Material aplicado.');return}
  if(d.iavol){const [tipo,forma]=d.iavol.split(':');if(document.getElementById('vivo')&&typeof vivoStartVol==='function'){vivoStartVol(tipo,forma);return}
    const v=volBlank(tipo);v.forma=forma;v.origen='ia';(P.volumenes=P.volumenes||[]).push(v);UI.vol=v.id;persist();document.getElementById('lb').hidden=true;goStep(3);toast(`${v.nombre} agregado. El asistente te preguntará sus medidas.`)}});
