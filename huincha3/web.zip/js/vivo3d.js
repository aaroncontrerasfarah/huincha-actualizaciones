/* Huincha — croquis 3D del recorrido en vivo, elementos del terreno, reconocimiento con IA y deshacer.
   Se apoya en el estado VV de vivo.js. Coordenadas de planta de la casa: x a lo largo de la fachada, y hacia el fondo. */
"use strict";
const V3={r:null,scene:null,cam:null,root:null,dyn:null,host:null,sig:'',th:-0.75,ph:0.95,rad:18,tgt:[4,3],user:0,raf:0,dirty:true,ptrs:new Map(),pinch:0,moved:0};

/* ---------- deshacer y rehacer ---------- */
const VSNAP=['st','i','sides','corners','marks','vols','rooms','elems','dims','closeErr','anchor','steps','heads','counting','h0'];
function vSnap(){if(!VV)return;const s={};for(const k of VSNAP)s[k]=VV[k]===undefined?null:JSON.parse(JSON.stringify(VV[k]));VV.hist.push(s);if(VV.hist.length>60)VV.hist.shift();VV.fut=[];vUndoBtns()}
function vRestore(s){for(const k of VSNAP)VV[k]=JSON.parse(JSON.stringify(s[k]));
  if(!Array.isArray(VV.heads))VV.heads=[];if(VV.steps==null)VV.steps=0;VV.counting=!!VV.counting;
  VV.meas=null;VV.vol=null;VV.room=null;VV.edit=null;VV.ia=null;VV.place=null;VV.sub=null;VV.sel=null;if(VV.eng==='ar'&&VV.st==='walk'&&!VV.anchor)VV.anchor=VV.corners[VV.corners.length-1]||null}
function vCur(){const s={};for(const k of VSNAP)s[k]=VV[k]===undefined?null:JSON.parse(JSON.stringify(VV[k]));return s}
function vUndo(){if(!VV.hist.length){toast('No hay nada que deshacer.');return}VV.fut.push(vCur());vRestore(VV.hist.pop());toast('Deshecho.');vPanel();vCroquis();vUndoBtns()}
function vRedo(){if(!VV.fut.length)return;VV.hist.push(vCur());vRestore(VV.fut.pop());toast('Rehecho.');vPanel();vCroquis();vUndoBtns()}
function vUndoBtns(){const u=$('#vundo'),r=$('#vredo');if(u)u.disabled=!VV?.hist.length;if(r)r.disabled=!VV?.fut.length}

/* ---------- posición actual en la planta ---------- */
const deg=Math.PI/180;
function vToHouse(p){const c=VV.corners;if(c.length>=2)return vArPlan(p);if(c.length===1)return[p[0]-c[0][0],-(p[2]-c[0][2])];return[p[0],-p[2]]}
/* Elementos marcados con realidad aumentada antes de conocer el frente: se reubican cuando ya hay dos esquinas */
function vFixAR(){if(VV.eng!=='ar'||VV.corners.length<2)return;for(const e of VV.elems){if(!e._ar)continue;const k=eltOf(e).k;
    if(k==='linea'){e.a=vToHouse(e._ar[0]);e.b=vToHouse(e._ar[1]||e._ar[0])}else if(e._ar.length>=2&&k!=='punto'){const a=vToHouse(e._ar[0]),b=vToHouse(e._ar[1]);e.x=(a[0]+b[0])/2;e.y=(a[1]+b[1])/2}else{const q=vToHouse(e._ar[0]);e.x=q[0];e.y=q[1]}
    delete e._ar}}
/* Dirección de la cámara en la planta según la brújula (pasos) */
function vHeadDir(h){if(h==null||VV.h0==null)return null;const a=(h-VV.h0)*deg;return[Math.cos(a),-Math.sin(a)]}
function vHere(){
  if(VV.eng==='ar'){const a=VV.ar;if(!a?.cam||VV.corners.length<1)return null;const p=vToHouse(a.cam),q=vToHouse([a.cam[0]+a.fwd[0],a.cam[1],a.cam[2]+a.fwd[2]]);const d=[q[0]-p[0],q[1]-p[1]],n=Math.hypot(...d)||1;return{p,dir:[d[0]/n,d[1]/n]}}
  const {pts,ang}=vPoly(),cur=pts[pts.length-1],wd=[Math.cos(ang),Math.sin(ang)];
  if(VV.st==='walk'){const d=VV.counting?VV.steps*VV.paso:0;const p=[cur[0]+wd[0]*d,cur[1]+wd[1]*d];VV.dr=p.slice();return{p,dir:vHeadDir(VV.head)||wd}}
  return{p:VV.dr||cur,dir:vHeadDir(VV.head)||wd}}
/* Un paso detectado fuera de la medición de lados: mueve la posición estimada */
function vDR(){if(!VV||VV.eng==='ar'||VV.st==='walk'||!VV.dr)return;const d=vHeadDir(VV.head);if(!d)return;VV.dr=[VV.dr[0]+d[0]*VV.paso,VV.dr[1]+d[1]*VV.paso];vCroquis()}

/* ---------- vista 3D ---------- */
function v3dInit(){const host=$('#v3d');if(!host||!window.THREE)return;V3.host=host;
  const r=new THREE.WebGLRenderer({antialias:true,alpha:false});r.setPixelRatio(Math.min(devicePixelRatio||1,2));r.outputEncoding=THREE.sRGBEncoding;r.toneMapping=THREE.ACESFilmicToneMapping;
  r.setClearColor(0xe9eef0);host.appendChild(r.domElement);V3.r=r;
  const S=new THREE.Scene();V3.scene=S;S.fog=new THREE.Fog(0xe9eef0,40,120);
  S.add(new THREE.HemisphereLight(0xffffff,0x8a8f7a,.85));const sun=new THREE.DirectionalLight(0xffffff,.9);sun.position.set(-8,14,10);S.add(sun);
  const gr=new THREE.Mesh(new THREE.PlaneGeometry(400,400),new THREE.MeshStandardMaterial({color:new THREE.Color('#d9dccf').convertSRGBToLinear(),roughness:1}));gr.rotation.x=-Math.PI/2;gr.position.y=-.01;S.add(gr);
  const grid=new THREE.GridHelper(200,200,0xb9beb3,0xc9cdc2);grid.position.y=0;S.add(grid);
  V3.cam=new THREE.PerspectiveCamera(50,1,.1,400);V3.dyn=new THREE.Group();S.add(V3.dyn);
  const el=r.domElement;el.style.touchAction='none';
  el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);V3.ptrs.set(e.pointerId,[e.clientX,e.clientY]);V3.moved=0;V3.down=[e.clientX,e.clientY];if(V3.ptrs.size===2){const [a,b]=[...V3.ptrs.values()];V3.pinch=Math.hypot(a[0]-b[0],a[1]-b[1])}});
  el.addEventListener('pointermove',e=>{if(!V3.ptrs.has(e.pointerId))return;const o=V3.ptrs.get(e.pointerId);const dx=e.clientX-o[0],dy=e.clientY-o[1];V3.ptrs.set(e.pointerId,[e.clientX,e.clientY]);V3.moved+=Math.abs(dx)+Math.abs(dy);
    if(V3.ptrs.size===1){V3.th-=dx*.008;V3.ph=Math.max(.15,Math.min(1.45,V3.ph-dy*.006))}
    else if(V3.ptrs.size===2){const [a,b]=[...V3.ptrs.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(V3.pinch)V3.rad=Math.max(3,Math.min(90,V3.rad*V3.pinch/d));V3.pinch=d}
    V3.user=1;V3.dirty=true});
  const up=e=>{V3.ptrs.delete(e.pointerId);if(V3.ptrs.size<2)V3.pinch=0;if(V3.moved<8&&e.type==='pointerup')v3dPick(e)};
  el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
  el.addEventListener('wheel',e=>{e.preventDefault();V3.rad=Math.max(3,Math.min(90,V3.rad*(e.deltaY>0?1.1:.9)));V3.user=1;V3.dirty=true},{passive:false});
  el.addEventListener('dblclick',()=>{V3.user=0;V3.sig='';vCroquis()});
  const loop=()=>{if(!V3.r)return;V3.raf=requestAnimationFrame(loop);v3dSize();if(V3.dirty){V3.dirty=false;v3dCam();V3.r.render(V3.scene,V3.cam)}};loop()}
function v3dSize(){const h=V3.host;if(!h||!V3.r)return;const w=h.clientWidth,ht=h.clientHeight;if(!w||!ht)return;if(V3.w!==w||V3.h!==ht){V3.w=w;V3.h=ht;V3.r.setSize(w,ht,false);V3.r.domElement.style.width=w+'px';V3.r.domElement.style.height=ht+'px';V3.cam.aspect=w/ht;V3.cam.updateProjectionMatrix();V3.dirty=true}}
function v3dCam(){const [tx,ty]=V3.tgt,c=V3.cam,R=V3.rad;c.position.set(tx+R*Math.sin(V3.ph)*Math.sin(V3.th),R*Math.cos(V3.ph),-ty+R*Math.sin(V3.ph)*Math.cos(V3.th));c.lookAt(tx,0.8,-ty)}
function v3dDispose(){cancelAnimationFrame(V3.raf);if(V3.r){V3.r.dispose();V3.r.domElement.remove()}Object.assign(V3,{r:null,scene:null,root:null,dyn:null,host:null,sig:'',user:0})}
function v3dPick(e){if(!V3.root)return;const rc=V3.r.domElement.getBoundingClientRect();const m=new THREE.Vector2((e.clientX-rc.left)/rc.width*2-1,-(e.clientY-rc.top)/rc.height*2+1);
  const ray=new THREE.Raycaster();ray.setFromCamera(m,V3.cam);const hit=ray.intersectObjects(V3.root.children,true).find(h=>h.object.userData.elem||h.object.userData.side!=null);
  if(!hit){if(VV.sel){VV.sel=null;if(VV.sub==='edit')VV.sub=null;vPanel();vCroquis()}return}
  if(hit.object.userData.elem){vSelElem(hit.object.userData.elem);return}
  if(hit.object.userData.side!=null&&VV.sides[hit.object.userData.side]){VV.edit=hit.object.userData.side;vPanel()}}

/* Arma la escena cuando cambia algo; lo que se mueve (posición y lado en curso) se actualiza siempre */
function v3dUpdate(){if(!V3.r||!VV)return;vFixAR();
  const sig=JSON.stringify([VV.sides,VV.marks.map(m=>[m.side,m.pos,m.tipo,m.sug]),VV.vols,VV.vol,VV.elems,VV.sel,VV.dims,VV.st==='walk']);
  if(sig!==V3.sig){V3.sig=sig;v3dBuild()}
  v3dDyn();V3.dirty=true}
function v3dBuild(){const S=V3.scene;if(V3.root){S.remove(V3.root);V3.root.traverse(o=>{if(o.geometry)o.geometry.dispose()})}
  const root=new THREE.Group();V3.root=root;S.add(root);
  const H=+P.casa.altura||2.4,{pts}=vPoly();const wallM=new THREE.MeshStandardMaterial({color:new THREE.Color('#efe9dc').convertSRGBToLinear(),roughness:.9});
  const box=(w,h,d,mat,x,y,z,ry=0)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.rotation.y=ry;root.add(m);return m};
  /* muros del contorno */
  for(let j=0;j<VV.sides.length;j++){const a=pts[j],b=pts[j+1];if(!a||!b)continue;const L=Math.hypot(b[0]-a[0],b[1]-a[1]);if(L<.05)continue;const ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
    const w=box(L+.15,H,.15,wallM,(a[0]+b[0])/2,H/2,-(a[1]+b[1])/2,ang);w.userData.side=j;
    const edge=new THREE.LineSegments(new THREE.EdgesGeometry(w.geometry),new THREE.LineBasicMaterial({color:0x14191a}));w.add(edge)}
  /* piso de la casa cuando el contorno está cerrado */
  if(VV.sides.length>=3&&VV.sides[VV.sides.length-1]?.closing){const sh=new THREE.Shape(pts.slice(0,-1).map(q=>new THREE.Vector2(q[0],q[1])));const g=new THREE.ShapeGeometry(sh);g.rotateX(-Math.PI/2);const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0xd8cfbf,roughness:1,side:THREE.DoubleSide}));m.position.y=.02;root.add(m)}
  /* puertas y ventanas marcadas */
  for(const m of VV.marks){if(m.tipo==='otro')continue;const j=m.side,a=pts[j];if(!a)continue;const b=pts[j+1]||null;const {ang}=vPoly();
    const dir=b?Math.atan2(b[1]-a[1],b[0]-a[0]):ang;const L=vSideLen(j)||m.pos||1;const t=b?Math.min(1,(m.pos||0)/L):0;const px=b?a[0]+(b[0]-a[0])*t:a[0]+Math.cos(dir)*(m.pos||0),py=b?a[1]+(b[1]-a[1])*t:a[1]+Math.sin(dir)*(m.pos||0);
    const isP=m.tipo==='puerta',w=isP?.9:1.2,h=isP?2.05:1.1,z0=isP?0:1;const mat=m.sug?new THREE.MeshBasicMaterial({color:0xf2b705,transparent:true,opacity:.5}):new THREE.MeshStandardMaterial({color:isP?0x7a4e2d:0x6fa8c8,roughness:isP?.7:.1,metalness:isP?0:.2});
    const nx=Math.sin(dir)*.1,ny=-Math.cos(dir)*.1;box(w,h,.08,mat,px+nx,z0+h/2,-(py+ny),dir)}
  /* volúmenes fuera del contorno (domo, segundo piso…) */
  const D=vDims();for(const v of [...VV.vols,VV.vol].filter(Boolean)){const g=vLiveVol(v,D.W||vSideLen(0)||0,D.L||vSideLen(1)||0);if(!g)continue;const z0=+v.nivel||0;const mat=new THREE.MeshStandardMaterial({color:0xf2c94c,roughness:.7,transparent:true,opacity:.85});
    if(g.circ){const s=new THREE.Mesh(new THREE.SphereGeometry(g.r,24,12,0,Math.PI*2,0,Math.PI/2),mat);s.position.set(g.cx,z0,-g.cy);root.add(s)}
    else box(g.w,2.4,g.h,mat,g.cx,z0+1.2,-g.cy);
    if(z0>0.3){const pm=new THREE.MeshStandardMaterial({color:0x6b5038});const r=g.circ?g.r*.7:0;for(const [u,w] of g.circ?[[r,0],[-r,0],[0,r],[0,-r]]:[[g.w/2-.1,g.h/2-.1],[-g.w/2+.1,g.h/2-.1],[g.w/2-.1,-g.h/2+.1],[-g.w/2+.1,-g.h/2+.1]])box(.12,z0,.12,pm,g.cx+u,z0/2,-(g.cy+w))}}
  /* elementos */
  for(const e of VV.elems){const g=elem3D(e);root.add(g);if(e.id===VV.sel){const bh=new THREE.BoxHelper(g,0xff5a1f);root.add(bh)}}
  /* encuadre automático hasta que el usuario mueva la vista */
  if(!V3.user){const bb=new THREE.Box3().setFromObject(root);if(!bb.isEmpty()){const c=bb.getCenter(new THREE.Vector3()),s=bb.getSize(new THREE.Vector3());V3.tgt=[c.x,-c.z];V3.rad=Math.max(8,Math.max(s.x,s.z)*1.35+4)}else{V3.tgt=[0,0];V3.rad=14}}}
function v3dDyn(){const G=V3.dyn;while(G.children.length){const o=G.children.pop();o.geometry?.dispose()}
  const {pts,ang}=vPoly(),cur=pts[pts.length-1];
  /* lado en curso */
  if(VV.st==='walk'){let e=null;if(VV.eng==='ar'){const c=VV.ar?.centro?.p;if(c){if(VV.corners.length>=2)e=vArPlan(c);else if(VV.corners.length===1){const d=hdist(VV.corners[0],c);e=[cur[0]+d*Math.cos(ang),cur[1]+d*Math.sin(ang)]}}}
    else if(VV.counting){const d=VV.steps*VV.paso;e=[cur[0]+d*Math.cos(ang),cur[1]+d*Math.sin(ang)]}
    if(e){const L=Math.hypot(e[0]-cur[0],e[1]-cur[1]);if(L>.05){const m=new THREE.Mesh(new THREE.BoxGeometry(L,+P.casa.altura||2.4,.06),new THREE.MeshBasicMaterial({color:0xe08a00,transparent:true,opacity:.35,depthWrite:false}));m.position.set((cur[0]+e[0])/2,(+P.casa.altura||2.4)/2,-(cur[1]+e[1])/2);m.rotation.y=Math.atan2(e[1]-cur[1],e[0]-cur[0]);G.add(m)}}}
  /* dónde estás */
  const here=vHere();if(here){const m=new THREE.Mesh(new THREE.ConeGeometry(.35,.9,16),new THREE.MeshBasicMaterial({color:0xff5a1f}));m.rotation.z=-Math.PI/2;const g=new THREE.Group();g.add(m);m.position.x=.2;g.position.set(here.p[0],.5,-here.p[1]);g.rotation.y=Math.atan2(here.dir[1],here.dir[0]);G.add(g)}}

/* ---------- croquis 2D: elementos ---------- */
function vElemSVG(){let h='';for(const e of VV.elems){const T=eltOf(e),cl=`vel${e.sug?' sug':''}${e.id===VV.sel?' sel':''}`;const P2=p=>`${p[0]},${-p[1]}`;
    if(T.k==='linea')h+=`<g class="${cl}" data-vel="${e.id}"><line x1="${e.a[0]}" y1="${-e.a[1]}" x2="${e.b[0]}" y2="${-e.b[1]}" class="ln" style="stroke:${T.col}"/><line x1="${e.a[0]}" y1="${-e.a[1]}" x2="${e.b[0]}" y2="${-e.b[1]}" class="hit"/></g>`;
    else if(T.k==='punto')h+=`<g class="${cl}" data-vel="${e.id}"><circle cx="${e.x}" cy="${-e.y}" r="${Math.max(.25,(e.w||1)/2)}" style="fill:${T.col}"/></g>`;
    else h+=`<g class="${cl}" data-vel="${e.id}"><polygon points="${elCorners(e).map(P2).join(' ')}" style="fill:${T.col}"/>${T.k==='vol'||e.t==='piscina'?`<text x="${e.x}" y="${-e.y+.2}" text-anchor="middle" class="vtx">${esc(elNombre(e))}</text>`:''}</g>`}
  const here=VV.eng==='pasos'&&VV.st!=='walk'&&VV.dr?VV.dr:null;if(here)h+=`<circle class="vme" cx="${here[0]}" cy="${-here[1]}" r=".35"/>`;
  return h}

/* ---------- agregar elementos ---------- */
const veBtn=(act,lab,cl='btn')=>`<button class="${cl}" type="button" data-ve="${act}">${lab}</button>`;
function vSelElem(id){VV.sel=id;VV.sub='edit';VV.place=null;vPanel();vCroquis()}
function vPalHTML(){return`<p class="vq">¿Qué quieres agregar?</p>${ELT_GRUPOS.map(g=>`<div class="fld"><span>${g}</span><div class="chips">${Object.entries(ELT).filter(([,t])=>t.g===g).map(([k,t])=>`<button class="chip" data-ve="pick:${k}">${t.n}</button>`).join('')}</div></div>`).join('')}
  <div class="vacts">${veBtn('x','Cancelar','btn ghost')}</div>`}
function vPlaceHTML(){const pl=VV.place,T=ELT[pl.t],ar=VV.eng==='ar';const need=T.k==='punto'?1:2,n=pl.pts.length;
  if(ar){const what=T.k==='linea'?(n?'el otro extremo':'un extremo'):T.k==='punto'?'el centro, donde toca el suelo':(n?'la esquina opuesta':'una esquina');
    return`<p class="vq">${esc(T.n)}: apunta la mira a ${what} y toca «Marcar».</p><p class="vh">${T.k==='linea'?'Se mide el largo entre los dos extremos.':T.k==='punto'?'Después podrás ajustar el tamaño.':'Marca dos esquinas opuestas, en diagonal.'}</p>
      <div class="vacts">${veBtn('mark','Marcar','btn pri')}${veBtn('typ','Usar medidas típicas aquí','btn')}${veBtn('x','Cancelar','btn ghost')}</div>`}
  return`<p class="vq">${esc(T.n)}: ¿dónde está?</p><p class="vh">Apunta la cámara hacia él. Se ubica en la dirección de la cámara a la distancia que indiques; después puedes moverlo y ajustar sus medidas.</p>
    <div class="vin"><label class="fld"><span>Distancia desde ti</span><div class="inp"><input id="ve-dist" inputmode="decimal" placeholder="0"><em>m</em></div></label></div>
    <div class="vacts">${veBtn('here','Ubicar','btn pri')}${veBtn('x','Cancelar','btn ghost')}</div>`}
function vEditHTML(){const e=VV.elems.find(x=>x.id===VV.sel);if(!e){VV.sub=null;return''}const T=eltOf(e);
  const f=(lab,k,v)=>`<label class="fld"><span>${lab}</span><div class="inp"><input data-vef="${k}" inputmode="decimal" value="${String(rr2(v)).replace('.',',')}"><em>m</em></div></label>`;
  const dims=T.k==='linea'?f('Largo','len',elLen(e))+f('Alto','h',e.h):T.k==='punto'?f('Diámetro','w',e.w)+f('Alto','h',e.h):f('Ancho','w',e.w)+f('Largo','l',e.l)+(T.k==='vol'||e.t==='piscina'||e.t==='escalera'||e.t==='jardinera'?f(e.t==='piscina'?'Profundidad':'Alto','h',e.h):'');
  return`<p class="vq">${esc(elNombre(e))}${e.sug?' <span class="badge">Reconocido por la IA</span>':''}</p>${e.det?`<p class="vh">${esc(e.det)}</p>`:''}
    <div class="vin vdims">${dims}</div>
    <div class="vpad"><span class="lbl">Mover 25 cm</span>${veBtn('mv:-1:0','←','btn sm')}${veBtn('mv:0:-1','Hacia la calle','btn sm')}${veBtn('mv:0:1','Hacia el fondo','btn sm')}${veBtn('mv:1:0','→','btn sm')}${T.k!=='punto'?veBtn('rot','Girar 15°','btn sm')+veBtn('rot90','Girar 90°','btn sm'):''}</div>
    <div class="vacts">${e.sug?veBtn('ok:'+e.id,'Aceptar','btn pri'):veBtn('done','Listo','btn pri')}${veBtn('del:'+e.id,e.sug?'Descartar':'Eliminar','btn danger')}</div>`}
function vSugHTML(){const S=VV.elems.filter(e=>e.sug),M=VV.marks.filter(m=>m.sug);
  if(!S.length&&!M.length){VV.sub=null;return''}
  return`${VV.escena?`<p class="vh"><b>Terreno:</b> ${esc(VV.escena.terreno)}${VV.escena.pendiente?' · '+esc(VV.escena.pendiente):''}. ${esc(VV.escena.resumen)}</p>`:''}<p class="vq">La IA reconoció ${S.length+M.length} elemento${S.length+M.length>1?'s':''}.</p><p class="vh">Aparecen en amarillo en el croquis. Acepta los correctos, descarta los que no, o toca uno para ajustarlo.</p>
    <div class="vlist">${S.map(e=>`<div class="vli"><button class="lnk" data-ve="sel:${e.id}"><b>${esc(elNombre(e))}</b><small>${elMedidas(e)}${e.conf?` · ${Math.round(e.conf*100)}% seguro`:''}</small></button>${veBtn('ok:'+e.id,'✓','btn sm pri')}${veBtn('del:'+e.id,'✕','btn sm')}</div>`).join('')}
      ${M.map(m=>`<div class="vli"><span><b>${m.tipo==='puerta'?'Puerta':'Ventana'}</b><small>${esc(sideName(m.side))} · a ${fmt(m.pos,1)} m</small></span>${veBtn('mok:'+m.id,'✓','btn sm pri')}${veBtn('mdel:'+m.id,'✕','btn sm')}</div>`).join('')}</div>
    <div class="vacts">${veBtn('okall','Aceptar todo','btn pri')}${veBtn('delall','Descartar todo','btn')}${veBtn('x','Cerrar','btn ghost')}</div>`}
function vListHTML(){const E=VV.elems,M=VV.marks;
  return`<p class="vq">Lo registrado</p>${!E.length&&!M.length?'<p class="vh">Todavía no hay elementos ni puertas o ventanas.</p>':''}
    <div class="vlist">${E.map(e=>`<div class="vli"><button class="lnk" data-ve="sel:${e.id}"><b>${esc(elNombre(e))}${e.sug?' (sugerido)':''}</b><small>${elMedidas(e)}</small></button>${veBtn('del:'+e.id,'✕','btn sm')}</div>`).join('')}
      ${M.map(m=>`<div class="vli"><span><b>${m.tipo==='puerta'?'Puerta':m.tipo==='ventana'?'Ventana':'Algo distinto'}</b><small>${esc(sideName(m.side))} · a ${fmt(m.pos,1)} m</small></span>${veBtn('mdel:'+m.id,'✕','btn sm')}</div>`).join('')}</div>
    <div class="vacts">${veBtn('x','Cerrar','btn pri')}</div>`}
function vSubHTML(){switch(VV.sub){case 'pal':return vPalHTML();case 'place':return vPlaceHTML();case 'edit':return vEditHTML();case 'sug':return vSugHTML();case 'list':return vListHTML()}return''}
function vToolsHTML(){const n=VV.elems.filter(e=>e.sug).length+VV.marks.filter(m=>m.sug).length;
  return`${veBtn('pal','+ Elemento','btn sm')}${veBtn('det',VV.detBusy?'Reconociendo…':'Reconocer con IA','btn sm')}${veBtn('auto',VV.auto?'Automático: sí':'Automático: no','btn sm ghost')}${n?veBtn('sug',`Revisar ${n}`,'btn sm pri'):''}${veBtn('list','Lista','btn sm ghost')}`}

/* Agrega un elemento en la planta y lo deja seleccionado para ajustarlo */
function vAddElem(e,{select=true}={}){VV.elems.push(e);if(select){VV.sel=e.id;VV.sub='edit'}VV.place=null;vPanel();vCroquis()}

/* ---------- reconocimiento con IA ---------- */
async function vCrop(blob,aspect){/* recorta la foto al formato de la pantalla para que x,y coincidan con la mira */
  try{const bm=await createImageBitmap(blob);let w=bm.width,h=bm.height,sx=0,sy=0;if(w/h>aspect){const nw=h*aspect;sx=(w-nw)/2;w=nw}else{const nh=w/aspect;sy=(h-nh)/2;h=nh}
    const k=Math.min(1,1280/Math.max(w,h));const cv=document.createElement('canvas');cv.width=Math.round(w*k);cv.height=Math.round(h*k);cv.getContext('2d').drawImage(bm,sx,sy,w,h,0,0,cv.width,cv.height);
    return await new Promise(r=>cv.toBlob(b=>r(b||blob),'image/jpeg',.82))}catch(e){return blob}}
function vDetCtx(){const lugar=VV.st==='walk'||VV.st==='confirm'?`caminando junto a: ${sideName(VV.i).toLowerCase()} de la casa`:VV.room?`dentro del recinto ${VV.room.nombre}`:'recorriendo el terreno alrededor de la casa';
  const ya=[...new Set(VV.elems.map(e=>elNombre(e)))];const es=VV.escena?`; ya se sabe del lugar: ${VV.escena.terreno}, pendiente ${VV.escena.pendiente}. ${VV.escena.resumen}`:'';
  return iaContexto(lugar+es+(ya.length?'; ya registrados (no repetir si son los mismos): '+ya.join(', '):''))}
async function vDetect(auto){if(!VV||VV.detBusy)return;const m=await IA.mode();if(!m){if(!auto)toast('Para reconocer con IA, guarda tu clave de API de Claude en el paso Proyecto.');VV.auto=false;vPanel();return}
  VV.detBusy=true;vPanel();let n=0;
  try{let blob=await vGrab();if(!blob)return;const ar=VV.eng==='ar';
    const asp=ar&&VV.ar?.w?VV.ar.w/VV.ar.h:null;if(asp)blob=await vCrop(blob,asp);
    const here=vHere(),hfov=ar&&VV.ar?.proj?2*Math.atan(1/VV.ar.proj[0])/deg:(()=>{const v=$('#vvid');return v&&v.videoWidth>v.videoHeight?63:48})();
    const snap=vCur();const res=await IA.detect(blob,vDetCtx());if(!VV)return;
    if(res.escena&&res.escena.terreno&&!VV.escena){VV.escena=res.escena;toast(`Terreno reconocido: ${res.escena.terreno}${res.escena.pendiente?', '+res.escena.pendiente:''}.`)}
    for(const o of res.objetos){const T=ELT[o.tipo];let pt=null,arRaw=null;
      if(ar){try{const r=await arPlugin().hitTest({x:o.x,y:o.y});arRaw=r.p}catch(e){}
        if(!arRaw&&VV.ar?.cam&&o.dist){const f=VV.ar.fwd,a=-(o.x-.5)*hfov*deg,c=Math.cos(a),s=Math.sin(a);const dx=f[0]*c+f[2]*s,dz=-f[0]*s+f[2]*c,n2=Math.hypot(dx,dz)||1;arRaw=[VV.ar.cam[0]+dx/n2*o.dist,VV.ar.cam[1]-1.4,VV.ar.cam[2]+dz/n2*o.dist]}
        if(arRaw)pt=vToHouse(arRaw)}
      else if(here){const d=o.dist||3,base=Math.atan2(here.dir[1],here.dir[0])-(o.x-.5)*hfov*deg;pt=[here.p[0]+Math.cos(base)*d,here.p[1]+Math.sin(base)*d]}
      if(!pt)continue;const size=Math.max(o.ancho||T.w||T.len||1,o.largo||0);
      if(VV.elems.some(e=>e.t===o.tipo&&(o.tipo!=='otro'||e.nombre===o.nombre)&&elDist(e,pt)<Math.max(1.5,size*.6)))continue;
      const view=here?Math.atan2(pt[1]-here.p[1],pt[0]-here.p[0]):0;const perp=[-Math.sin(view),Math.cos(view)];
      const e=elemNew(o.tipo,pt,T.k==='linea'?perp:[1,0]);if(T.k==='linea'){if(o.ancho)elSetLen(e,o.ancho);/* elemNew parte desde pt: centrarlo */elMove(e,-(e.b[0]-e.a[0])/2,-(e.b[1]-e.a[1])/2)}
      else{if(o.ancho)e.w=o.ancho;if(o.largo)e.l=o.largo;if(T.k==='punto')e.l=e.w}
      if(o.alto)e.h=T.k==='area'&&o.tipo!=='piscina'&&o.tipo!=='escalera'&&o.tipo!=='jardinera'?e.h:o.alto;
      e.sug=true;e.conf=o.conf;e.det=o.detalle;if(o.nombre)e.nombre=o.nombre;if(arRaw&&VV.corners.length<2)e._ar=[arRaw];VV.elems.push(e);n++}
    /* puertas y ventanas sobre el lado que se está recorriendo */
    if(VV.st==='walk'||VV.st==='confirm'){for(const v of res.vanos){let pos=vLiveDist()||0;
        if(ar&&VV.anchor){try{const r=await arPlugin().hitTest({x:v.x,y:v.y});pos=hdist(VV.anchor,r.p)}catch(e){continue}}
        if(VV.marks.some(m=>m.side===VV.i&&m.tipo===v.tipo&&Math.abs((m.pos||0)-pos)<.8))continue;VV.marks.push({id:uid(),side:VV.i,pos,tipo:v.tipo,sug:true,t:vRecT()});n++}}
    if(res.piso&&VV.room){VV.room.piso=res.piso;toast(`Piso de ${VV.room.nombre}: ${MATS.piso.opts[res.piso].n}.`)}
    if(n){VV.hist.push(snap);VV.fut=[];if(!auto)VV.sub='sug';toast(`La IA reconoció ${n} elemento${n>1?'s':''}. Revísalo${n>1?'s':''} en el croquis.`)}
    else if(!auto)toast('La IA no reconoció elementos nuevos en esta imagen.')}
  catch(err){if(!auto)toast(iaErrorMsg(err));else{VV.auto=false;toast('Se detuvo el reconocimiento automático: '+iaErrorMsg(err))}}
  finally{if(VV){VV.detBusy=false;vPanel();vCroquis();vUndoBtns()}}}
setInterval(()=>{if(VV&&VV.auto&&!VV.detBusy&&!VV.sub&&!VV.meas&&document.visibilityState==='visible')vDetect(true)},9000);

/* ---------- acciones ---------- */
document.addEventListener('click',async ev=>{const b=ev.target.closest('[data-ve],[data-vel],[data-v3]');if(!b||!VV)return;
  if(b.dataset.vel){vSelElem(b.dataset.vel);return}
  if(b.dataset.v3){const a=b.dataset.v3;
    if(a==='undo')vUndo();else if(a==='redo')vRedo();
    else if(a==='vista'){VV.view=VV.view==='3d'?'2d':'3d';$('#vcro').dataset.view=VV.view;b.textContent=VV.view==='3d'?'Ver 2D':'Ver 3D';const lb=$('#vcro .vcro-lbl');if(lb)lb.textContent=VV.view==='3d'?'Croquis 3D · arrastra para girar · toca un elemento para editarlo':'Croquis · toca una medida o un elemento para corregirlo';V3.sig='';vCroquis()}
    else if(a==='big'){$('#vivo').classList.toggle('crobig');V3.dirty=true;setTimeout(()=>{V3.w=0;vCroquis()},60)}
    else if(a==='fit'){V3.user=0;V3.sig='';vCroquis()}
    return}
  const [a,x,y,z]=b.dataset.ve.split(':');const e=VV.elems.find(q=>q.id===(a==='sel'?x:VV.sel));
  switch(a){
    case 'pal':VV.sub='pal';VV.sel=null;vPanel();break;
    case 'pick':VV.place={t:x,pts:[]};VV.sub='place';vPanel();break;
    case 'x':VV.sub=null;VV.place=null;VV.sel=null;vPanel();vCroquis();break;
    case 'mark':{const p=await arFix();if(!p)break;const pl=VV.place,T=ELT[pl.t];pl.pts.push(p);const need=T.k==='punto'?1:2;
      if(pl.pts.length<need){toast('Listo. Ahora el otro punto.');vPanel();break}
      vSnap();const H=pl.pts.map(vToHouse);let el;
      if(T.k==='linea'){el=elemNew(pl.t,H[0],[H[1][0]-H[0][0],H[1][1]-H[0][1]]);el.b=H[1]}
      else if(T.k==='punto')el=elemNew(pl.t,H[0]);
      else{el=elemNew(pl.t,[(H[0][0]+H[1][0])/2,(H[0][1]+H[1][1])/2]);el.w=Math.max(.3,Math.abs(H[1][0]-H[0][0]));el.l=Math.max(.3,Math.abs(H[1][1]-H[0][1]))}
      if(VV.corners.length<2)el._ar=pl.pts.slice();vAddElem(el);toast(`${T.n} agregado.`);break}
    case 'typ':{const p=await arFix();if(!p)break;vSnap();const h=vHere();const el=elemNew(VV.place.t,vToHouse(p),h?[-h.dir[1],h.dir[0]]:[1,0]);if(VV.corners.length<2)el._ar=[p];vAddElem(el);break}
    case 'here':{const h=vHere();if(!h){toast('Marca primero la esquina inicial de la casa.');break}const dEl=$('#ve-dist');const d=dEl&&dEl.value.trim()?num(dEl.value)||0:0;vSnap();
      const el=elemNew(VV.place.t,[h.p[0]+h.dir[0]*d,h.p[1]+h.dir[1]*d],ELT[VV.place.t].k==='linea'?[-h.dir[1],h.dir[0]]:[1,0]);vAddElem(el);break}
    case 'sel':vSelElem(x);break;
    case 'mv':if(e){vSnap();elMove(e,+x*.25,+y*.25);vPanel();vCroquis()}break;
    case 'rot':if(e){vSnap();elRotate(e,15*deg);vCroquis()}break;
    case 'rot90':if(e){vSnap();elRotate(e,90*deg);vCroquis()}break;
    case 'done':VV.sub=VV.elems.some(q=>q.sug)?'sug':null;VV.sel=null;vPanel();vCroquis();break;
    case 'ok':{const q=VV.elems.find(k=>k.id===x);if(q){vSnap();delete q.sug}VV.sel=null;VV.sub=VV.elems.some(k=>k.sug)||VV.marks.some(k=>k.sug)?'sug':null;vPanel();vCroquis();break}
    case 'del':vSnap();VV.elems=VV.elems.filter(k=>k.id!==x);if(VV.sel===x)VV.sel=null;VV.sub=VV.sub==='list'?'list':VV.elems.some(k=>k.sug)||VV.marks.some(k=>k.sug)?'sug':null;vPanel();vCroquis();break;
    case 'mok':{const m=VV.marks.find(k=>k.id===x);if(m){vSnap();delete m.sug}vPanel();vCroquis();break}
    case 'mdel':vSnap();VV.marks=VV.marks.filter(k=>k.id!==x);vPanel();vCroquis();break;
    case 'okall':vSnap();VV.elems.forEach(k=>delete k.sug);VV.marks.forEach(k=>delete k.sug);VV.sub=null;VV.sel=null;vPanel();vCroquis();toast('Elementos aceptados.');break;
    case 'delall':vSnap();VV.elems=VV.elems.filter(k=>!k.sug);VV.marks=VV.marks.filter(k=>!k.sug);VV.sub=null;VV.sel=null;vPanel();vCroquis();break;
    case 'sug':VV.sub='sug';vPanel();break;
    case 'list':VV.sub='list';vPanel();break;
    case 'det':vDetect(false);break;
    case 'auto':VV.auto=!VV.auto;vPanel();toast(VV.auto?'La IA revisará la cámara cada 9 segundos mientras caminas. Cada revisión tiene un costo pequeño en tu cuenta de Claude.':'Reconocimiento automático detenido.');if(VV.auto)vDetect(true);break}});
/* medidas escritas en el panel de edición */
document.addEventListener('change',ev=>{const t=ev.target;if(!VV||!t.dataset||!t.dataset.vef)return;const e=VV.elems.find(q=>q.id===VV.sel);const v=num(t.value);if(!e||!(v>0))return;vSnap();
  if(t.dataset.vef==='len')elSetLen(e,v);else{e[t.dataset.vef]=v;if(eltOf(e).k==='punto'&&t.dataset.vef==='w')e.l=v}vCroquis()});
