/* Huincha — fachadas con IA.
   En cada fachada (principal, costados y posterior) se toma una foto: la IA reconoce el muro, las aguas del techo,
   puertas, ventanas y materiales; la app pregunta lo que falta (ancho, alto, tipo de techo), registra el norte con
   la brújula y lo dibuja en el croquis 3D. Todo pasa al proyecto para los planos, la visita guiada y la cubicación. */
"use strict";
const FLADO=[{k:'frontal',n:'Fachada principal',ins:'Párate frente a la casa, a unos pasos, para que se vea completa con su techo.'},
  {k:'derecho',n:'Costado derecho',ins:'Párate frente al costado derecho de la casa (mirando desde la calle), para que se vea entero con su techo.'},
  {k:'posterior',n:'Fachada posterior',ins:'Párate en el patio, frente a la fachada de atrás, para que se vea completa.'},
  {k:'izquierdo',n:'Costado izquierdo',ins:'Párate frente al costado izquierdo de la casa, para que se vea entero con su techo.'}];
const FTECHO={'dos-aguas':'Dos aguas','un-agua':'Un agua','plana':'Plano'};
const FVANO={puerta:'Puerta',ventana:'Ventana',ventanal:'Ventanal',porton_garage:'Portón de garaje'};

function promptFachada(lado,ctx){return`Eres arquitecto y analizas una foto de una vivienda chilena para levantar sus planos.
La foto muestra: ${lado}. Contexto: ${ctx}
Responde SOLO con JSON, sin texto adicional:
{"caja_muro":[x0,y0,x1,y1],"ancho_estimado":8.5,"alto_muro":2.4,"pisos":1,
 "techo":{"tipo":"dos-aguas|un-agua|plana","aguas":2,"cumbrera":"paralela|perpendicular","alto_sobre_muro":1.6,"cubierta":"clave o null"},
 "vanos":[{"tipo":"puerta|ventana|ventanal|porton_garage","caja":[x0,y0,x1,y1]}],
 "materiales":{"revExt":"clave o null","zocalo":"clave o null","ventanas":"clave o null"},
 "elementos":[{"tipo":"clave","caja":[x0,y0,x1,y1],"ancho":3,"fondo":2,"alto":0.3,"dist":0,"material":"clave o null","detalle":"breve"}],
 "dist_reja":5.5,
 "resumen":"una frase con lo que se ve","conf":0.8}
- Coordenadas de 0 a 1 en la imagen (0 = izquierda/arriba). "caja_muro": el muro de esta fachada desde el suelo hasta el alero, sin el techo.
- "vanos": cada puerta, ventana, ventanal o portón de garaje de ESTA fachada, con su recuadro exacto (solo marcos, sin rejas de protección).
- "cumbrera": "paralela" si la línea más alta del techo corre a lo ancho de esta fachada; "perpendicular" si va hacia el fondo (se ve un triángulo o frontón).
- "alto_sobre_muro": cuánto sube el techo desde el alero hasta la cumbrera.
- "elementos": TODO lo constructivo que se ve delante o al lado de esta fachada, no solo el muro: terraza, escalera o gradas, rampa, baranda, pilares, alero o corredor techado (cobertizo/pergola), radier o piso exterior, camino de acceso, estacionamiento, jardinera, reja, portón, muro, ampliación (edificacion), chimenea, etc. Claves válidas: ${Object.keys(ELT).join(', ')}.
  "ancho": medida a lo largo de la fachada; "fondo": cuánto se adelanta desde el muro hacia afuera; "dist": distancia desde el muro hasta su borde más cercano (0 si está pegado); materiales válidos según el tipo: pisos y terrazas ${Object.keys(MATOPC.piso).join(', ')}; cierres ${Object.keys(MATOPC.cierre).join(', ')}.
- "dist_reja": distancia en metros desde esta fachada hasta la reja o portón del frente, si se ve; si no, null.
- Estima medidas comparando con puertas de 2 m de alto y 0,9 m de ancho, peldaños de 18 cm y paños de reja de 2 a 2,5 m.
- Claves de cubierta: ${Object.keys(MATS.cubierta.opts).join(', ')}. revExt: ${Object.keys(MATS.revExt.opts).join(', ')}. zocalo: ${Object.keys(MATS.zocalo.opts).join(', ')}. ventanas: ${Object.keys(MATS.ventanas.opts).join(', ')}. Usa null si no se distingue.
Escribe en español de Chile.`}
async function iaFachada(blob,lado){const o=await IA.ask(blob,promptFachada(lado,iaContexto()),1400);const n01=v=>Math.max(0,Math.min(1,+v||0));const cj=c=>Array.isArray(c)&&c.length===4?c.map(n01):null;
  const t=o.techo||{},m=o.materiales||{},ok=(cat,k)=>MATS[cat]?.opts[k]?k:null;
  return{caja:cj(o.caja_muro)||[.1,.3,.9,.9],ancho:+o.ancho_estimado>0?+o.ancho_estimado:null,alto:+o.alto_muro>0?+o.alto_muro:null,pisos:Math.max(1,Math.round(+o.pisos||1)),
    techo:{tipo:FTECHO[t.tipo]?t.tipo:null,cumbrera:t.cumbrera==='perpendicular'?'perpendicular':'paralela',alto:+t.alto_sobre_muro>0?+t.alto_sobre_muro:null,cubierta:ok('cubierta',t.cubierta)},
    vanos:(Array.isArray(o.vanos)?o.vanos:[]).filter(v=>FVANO[v.tipo]&&cj(v.caja)).slice(0,14).map(v=>({tipo:v.tipo,caja:cj(v.caja),on:true})),
    mat:{revExt:ok('revExt',m.revExt),zocalo:ok('zocalo',m.zocalo),ventanas:ok('ventanas',m.ventanas)},
    els:(Array.isArray(o.elementos)?o.elementos:[]).filter(x=>ELT[x.tipo]&&cj(x.caja)).slice(0,12).map(x=>({tipo:x.tipo,caja:cj(x.caja),ancho:+x.ancho>0?+x.ancho:null,fondo:+x.fondo>0?+x.fondo:null,alto:+x.alto>0?+x.alto:null,dist:+x.dist>=0?+x.dist:0,mat:(MATOPC[MATGRP[x.tipo]]||{})[x.material]?x.material:null,det:String(x.detalle||''),on:true})),
    distReja:+o.dist_reja>0?+o.dist_reja:null,resumen:String(o.resumen||''),conf:+o.conf||.6}}

/* rumbo absoluto de la brújula (para el norte), leído en el momento de la foto */
function vLeerRumbo(){return new Promise(res=>{if(VV.absOk&&VV.head!=null)return res(VV.head);let done=false;const h=e=>{vOrient(e,true);if(VV.head!=null&&VV.absOk&&!done){done=true;fin()}};
  const fin=()=>{window.removeEventListener('deviceorientationabsolute',h);res(VV.absOk?VV.head:null)};window.addEventListener('deviceorientationabsolute',h);setTimeout(()=>{if(!done){done=true;fin()}},1500)})}

/* ancho conocido de la fachada: lado recorrido, casa del mapa o lo que ya se respondió */
function fAnchoConocido(i){const s=VV.sides[i];if(s)return s.len??s.est;const c=P.casa;if(+c.ancho>0)return i%2===0?+c.ancho:+c.largo;return VV.fachW?.[i]||null}
async function vFachadaFoto(i){if(VV.fBusy)return;VV.fBusy=true;VV.fRes=null;vPanel();
  try{const rumbo=i===0?await vLeerRumbo():null;let blob=await vGrab();if(!blob)return;if(VV.eng==='ar'&&VV.ar?.w)blob=await vCrop(blob,VV.ar.w/VV.ar.h);
    const img=URL.createObjectURL(blob);const r=await iaFachada(blob,FLADO[i].n.toLowerCase());if(!VV)return;
    r.img=img;r.lado=i;r.rumbo=rumbo;r.DR=r.distReja||null;r.W=fAnchoConocido(i)||r.ancho||(i%2===0?9:8);r.H=r.alto||+P.casa.altura||2.4;
    VV.fRes=r;vFachadaPreview(i);try{const ph=await storePhoto(blob);P.fotos[['frontal','derecha','posterior','izquierda'][i]].push(ph);persist()}catch(e){}}
  catch(err){toast(iaErrorMsg(err)+(err?.message?` (${err.message})`:''))}
  finally{if(VV){VV.fBusy=false;vPanel()}}}

/* panel de revisión de la fachada analizada */
function vFachadaHTML(i){const r=VV.fRes;const L=FLADO[i];
  if(VV.fBusy)return`<p class="vh"><b>La IA está analizando la fachada…</b> Reconoce el muro, las aguas del techo, puertas, ventanas y materiales.</p>`;
  if(!r||r.lado!==i)return`<p class="vh">${esc(L.ins)} Con una foto la IA reconoce las aguas del techo, puertas, ventanas y materiales${i===0?', y la brújula registra el norte':''}.</p>
    <div class="vacts"><button class="btn pri" data-vfa="foto:${i}">Foto de la fachada</button>${VV.fach?.[i]?'<span class="lbl">✓ Ya registrada</span>':''}</div>`;
  return fReviewHTML(r,VV.techo||r.techo,i,'vfa')}
/* medidas de cada vano en metros, desde su recuadro (o lo que escribió el usuario) */
function fVanoMed(r,v){const c=r.caja,cw=(c[2]-c[0])||1,ch=(c[3]-c[1])||1;const fx0=(v.caja[0]-c[0])/cw,fx1=(v.caja[2]-c[0])/cw,fyb=(c[3]-v.caja[3])/ch,fyt=(c[3]-v.caja[1])/ch;
  const win=v.tipo==='ventana'||v.tipo==='ventanal';const m=v.m||{};
  return{ancho:rr2(m.ancho??Math.max(.4,(fx1-fx0)*r.W)),alto:rr2(m.alto??Math.max(.4,(fyt-fyb)*r.H)),ante:win?rr2(m.ante??Math.max(0,fyb*r.H)):0,pos:rr2(Math.max(0,Math.min(r.W,(fx0+fx1)/2*r.W))),win}}
/* revisión común: en el recorrido en vivo (pre='vfa') y en las fotos del proyecto (pre='pfa') */
function fReviewHTML(r,T,i,pre){const L=FLADO[i];const c=r.caja,hd='<i class="fh" data-fh="tl"></i><i class="fh" data-fh="tr"></i><i class="fh" data-fh="bl"></i><i class="fh" data-fh="br"></i>';
  const box=(b,cl,t,key)=>`<span class="${cl}" data-fbox="${key}" style="left:${b[0]*100}%;top:${b[1]*100}%;width:${(b[2]-b[0])*100}%;height:${(b[3]-b[1])*100}%">${t?`<em>${t}</em>`:''}${hd}</span>`;
  const TH=r.TH||T.alto||r.techo.alto||1.5,yA=c[1]-(TH/(r.H||2.4))*(c[3]-c[1]);
  const roof=T.tipo&&T.tipo!=='plana'?`<svg class="froof" viewBox="0 0 100 100" preserveAspectRatio="none"><polygon points="${(T.cumbrera==='perpendicular'?[[c[0],c[1]],[(c[0]+c[2])/2,yA],[c[2],c[1]]]:T.tipo==='un-agua'?[[c[0],c[1]],[c[0],yA],[c[2],c[1]]]:[[c[0],c[1]],[c[0]+(c[2]-c[0])*.18,yA],[c[2]-(c[2]-c[0])*.18,yA],[c[2],c[1]]]).map(q=>`${q[0]*100},${q[1]*100}`).join(' ')}"/></svg><span class="fapex" data-fbox="apex" style="left:${(c[0]+c[2])/2*100}%;top:${yA*100}%"></span>`:'';
  const on=r.vanos.filter(v=>v.on);const nP=on.filter(v=>v.tipo==='puerta').length,nV=on.filter(v=>v.tipo==='ventana'||v.tipo==='ventanal').length,nG=on.filter(v=>v.tipo==='porton_garage').length;
  const resumen=[nP?`${nP} puerta${nP>1?'s':''}`:'',nV?`${nV} ventana${nV>1?'s':''}`:'',nG?'portón de garaje':'',T.tipo?`techo ${FTECHO[T.tipo].toLowerCase()}`:'',r.pisos>1?`${r.pisos} pisos`:''].filter(Boolean).join(' · ');
  const chips=(k,opts,cur)=>`<div class="chips">${Object.entries(opts).map(([v,l])=>`<button class="chip" data-${pre}="set:${k}:${v}" aria-pressed="${cur===v}">${l}</button>`).join('')}</div>`;
  const nin=(lab,k,v)=>`<label class="fld"><span>${lab}</span><div class="inp"><input data-${pre}n="${k}" inputmode="decimal" value="${String(rr2(v)).replace('.',',')}"><em>m</em></div></label>`;
  const cnt={};const rows=r.vanos.map((v,k)=>{const t=FVANO[v.tipo];cnt[t]=(cnt[t]||0)+1;const M=fVanoMed(r,v);const f=(campo,val,lab)=>`<label class="vmini"><span>${lab}</span><input data-${pre}v="${k}:${campo}" inputmode="decimal" value="${String(val).replace('.',',')}"></label>`;
    return`<div class="fvrow${v.on?'':' off'}"><button class="chip" data-${pre}="van:${k}" aria-pressed="${v.on}">${t} ${cnt[t]}</button>${v.on?`${f('ancho',M.ancho,'Ancho')}${f('alto',M.alto,'Alto')}${M.win?f('ante',M.ante,'Antepecho'):''}<span class="lbl">a ${fmt(M.pos,1)} m</span>`:'<span class="lbl">Quitado</span>'}</div>`}).join('');
  r.els=r.els||[];const els=r.els.map((x,k)=>x.on?box(x.caja,'fel',ELT[x.tipo].n,'e:'+k):'').join('');
  const erows=r.els.map((x,k)=>{const f=(campo,val,lab)=>`<label class="vmini"><span>${lab}</span><input data-${pre}e="${k}:${campo}" inputmode="decimal" value="${String(rr2(val)).replace('.',',')}"></label>`;const T=ELT[x.tipo],D=fElDims(r,x);
    return`<div class="fvrow${x.on?'':' off'}"><button class="chip" data-${pre}="el:${k}" aria-pressed="${x.on}">${esc(T.n)}</button>${x.on?`${f('ancho',D.ancho,T.k==='linea'?'Largo':'Ancho')}${T.k==='area'||T.k==='vol'?f('fondo',D.fondo,'Fondo'):''}${f('dist',D.dist,'Separación')}${(MATOPC[MATGRP[x.tipo]]&&x.mat)?`<span class="lbl">${esc(MATOPC[MATGRP[x.tipo]][x.mat].n)}</span>`:''}`:'<span class="lbl">Quitado</span>'}</div>`}).join('');
  return`<div class="vthumb fthumb"><span class="vti" data-fed="${pre}"><img src="${r.img}" alt="Fachada analizada" draggable="false">${roof}${box(c,'fmuro','','m')}${els}${r.vanos.map((v,k)=>v.on?box(v.caja,'fvano',v.tipo==='puerta'?'P':v.tipo==='porton_garage'?'G':'V','v:'+k):'').join('')}</span></div>
    <p class="vh">Arrastra los recuadros o sus esquinas para delinear el muro, cada puerta y ventana${T.tipo&&T.tipo!=='plana'?', y el punto blanco para la altura del techo':''}.</p>
    <div class="chips">${Object.entries(FVANO).map(([k,n])=>`<button class="chip" data-${pre}="add:${k}">+ ${n}</button>`).join('')}</div>
    <p class="vq">${esc(resumen||'Sin puertas ni ventanas reconocidas')}</p>${r.resumen?`<p class="vh">${esc(r.resumen)}</p>`:''}
    ${i===0&&r.rumbo!=null?`<p class="vh">🧭 Norte registrado: mirando hacia la casa estás a ${Math.round(r.rumbo)}° (${rumboTxt(r.rumbo)}).</p>`:''}
    <div class="vin vdims">${nin(`Ancho de la ${L.n.toLowerCase()}`,'W',r.W)}${nin('Alto del muro','H',r.H)}</div>
    <div class="fld"><span>Puertas y ventanas: corrige las medidas o toca el nombre para quitarla</span>${rows||'<span class="lbl">Ninguna</span>'}</div>
    <div class="fld"><span>Elementos constructivos frente a esta fachada (terrazas, escaleras, pisos, pilares, cierres…)</span>${erows||'<span class="lbl">Ninguno reconocido</span>'}
      <div class="chips">${['terraza','escalera','radier','camino','pilar','baranda','cobertizo','jardinera','reja','porton'].map(k=>`<button class="chip" data-${pre}="adde:${k}">+ ${ELT[k].n}</button>`).join('')}</div></div>
    ${i===0?`<div class="vin vdims">${nin('Distancia de la fachada a la reja o portón','DR',r.distReja||+P.casa.retiroFrontal||4)}</div>`:''}
    <div class="fld"><span>Techo</span>${chips('techo',FTECHO,T.tipo||'')}${T.tipo&&T.tipo!=='plana'?chips('cumbrera',{paralela:'Cumbrera a lo ancho',perpendicular:'Cumbrera hacia el fondo'},T.cumbrera||'paralela'):''}${T.tipo&&T.tipo!=='plana'?`<div class="vin vdims">${nin('Altura del techo sobre el muro','TH',T.alto||r.techo.alto||1.5)}</div>`:''}</div>
    ${r.mat.revExt||r.techo.cubierta?`<p class="vh">Materiales: ${[r.mat.revExt?MATS.revExt.opts[r.mat.revExt].n:'',r.techo.cubierta?MATS.cubierta.opts[r.techo.cubierta].n:''].filter(Boolean).join(' · ')}.</p>`:''}
    <div class="vacts"><button class="btn pri" data-${pre}="ok:${i}">Confirmar y dibujar</button><button class="btn" data-${pre}="foto:${i}">Otra foto</button></div>`}
/* ---------- delinear sobre la foto: mover y ajustar recuadros con el dedo ---------- */
function fEdState(pre){if(pre==='vfa')return VV?.fRes;if(pre==='pfa')return FP?.res;return null}
function fEdCommit(pre){if(pre==='vfa'){vFachadaPreview(VV.fRes.lado);vPanel()}else if(pre==='pfa')fProyPinta();else if(pre==='det')vDetBoxCommit()}
(function(){let D=null;const clamp=v=>Math.max(0,Math.min(1,v));
  document.addEventListener('pointerdown',e=>{const host=e.target.closest('.vti[data-fed]');if(!host)return;const bx=e.target.closest('[data-fbox]');if(!bx)return;e.preventDefault();
    const pre=host.dataset.fed,key=bx.dataset.fbox,h=e.target.closest('[data-fh]')?.dataset.fh||'move',rc=host.getBoundingClientRect();
    const el=bx,st={l:parseFloat(el.style.left)/100,t:parseFloat(el.style.top)/100,w:parseFloat(el.style.width||0)/100,h:parseFloat(el.style.height||0)/100};
    D={pre,key,h,rc,x:e.clientX,y:e.clientY,el,st,host};try{host.setPointerCapture(e.pointerId)}catch(x){}});
  document.addEventListener('pointermove',e=>{if(!D)return;const dx=(e.clientX-D.x)/D.rc.width,dy=(e.clientY-D.y)/D.rc.height,s=D.st;let l=s.l,t=s.t,w=s.w,h=s.h;
    if(D.key==='apex'){t=clamp(s.t+dy);D.el.style.top=t*100+'%';return}
    if(D.h==='move'){l=clamp(s.l+dx);t=clamp(s.t+dy)}else{if(D.h.includes('l')){l=clamp(s.l+dx);w=s.w-(l-s.l)}if(D.h.includes('r'))w=s.w+dx;if(D.h.includes('t')){t=clamp(s.t+dy);h=s.h-(t-s.t)}if(D.h.includes('b'))h=s.h+dy}
    w=Math.max(.02,Math.min(1-l,w));h=Math.max(.02,Math.min(1-t,h));Object.assign(D.el.style,{left:l*100+'%',top:t*100+'%',width:w*100+'%',height:h*100+'%'});D.cur=[l,t,l+w,t+h]});
  const up=()=>{if(!D)return;const d=D;D=null;const r=d.pre==='det'?null:fEdState(d.pre);
    if(d.key==='apex'&&r){const c=r.caja,yA=parseFloat(d.el.style.top)/100;r.TH=rr2(Math.max(.2,(c[1]-yA)/((c[3]-c[1])||1)*(r.H||2.4)));const T=d.pre==='vfa'?(VV.techo||(VV.techo={...r.techo})):FP.T;T.alto=r.TH}
    else if(d.cur){if(d.pre==='det'){VV._detBox=d.cur}else if(d.key==='m')r.caja=d.cur;else if(d.key.startsWith('e:')){const x=r.els[+d.key.split(':')[1]];x.caja=d.cur;delete x.ancho}else{const v=r.vanos[+d.key.split(':')[1]];v.caja=d.cur;delete v.m}}
    else return;fEdCommit(d.pre)};
  document.addEventListener('pointerup',up);document.addEventListener('pointercancel',up)})();
/* agrega una puerta o ventana al centro del muro, para delinearla */
function fAddVano(r,tipo){const c=r.caja,cw=c[2]-c[0],ch=c[3]-c[1],W=r.W||9,H=r.H||2.4;const w=(tipo==='puerta'?.9:tipo==='porton_garage'?2.8:tipo==='ventanal'?2.2:1.2)/W*cw,h=(tipo==='puerta'?2.05:tipo==='porton_garage'?2.1:tipo==='ventanal'?2:1.1)/H*ch;
  const bot=tipo==='ventana'?c[3]-1/H*ch:c[3];const x0=(c[0]+c[2])/2-w/2;r.vanos.push({tipo,caja:[x0,Math.max(0,bot-h),x0+w,bot],on:true})}
/* agrega un elemento constructivo al pie del muro, para delinearlo */
function fAddEl(r,tipo){const c=r.caja,cw=c[2]-c[0],T=ELT[tipo];const w=Math.min(cw,((T.w||T.len||1.5))/(r.W||9)*cw);const x0=(c[0]+c[2])/2-w/2;(r.els=r.els||[]).push({tipo,caja:[x0,Math.min(.97,c[3]-.04),x0+w,Math.min(1,c[3]+.08)],dist:0,on:true})}
/* el croquis 3D se actualiza mientras se delinea */
function vFachadaPreview(i){const r=VV.fRes;if(!r)return;if(!r._snap){vSnap();r._snap=1}
  VV.marks=VV.marks.filter(m=>!(m.side===i&&m.src==='fachada'));
  for(const v of r.vanos){if(!v.on)continue;const M=fVanoMed(r,v);VV.marks.push({id:uid(),side:i,pos:M.pos,tipo:M.win?'ventana':'puerta',ancho:M.ancho,alto:M.alto,antepecho:M.ante,src:'fachada',vano:v.tipo})}
  (VV.fachW=VV.fachW||{})[i]=r.W;VV.altoMuro=r.H;VV.pisos=Math.max(VV.pisos||1,r.pisos);
  const T=VV.techo||r.techo;if(T.tipo)VV.techo={tipo:T.tipo,cumbrera:T.cumbrera||'paralela',alto:r.TH||T.alto||r.techo.alto||null,cubierta:T.cubierta||r.techo.cubierta||null};
  {const cp=vCasaPrevia(),W=VV.sides.length?vSideLen(0)||r.W:cp?.w||r.W,L=VV.sides.length?vSideLen(1)||r.W*.8:cp?.l||r.W*.8;VV.elems=VV.elems.filter(e=>!(e.src==='fachada'&&e.fach===i));VV.elems.push(...fElementos(r,i,W,L))}
  if(i===0&&r.DR){P.casa.retiroFrontal=rr2(r.DR)}
  V3.sig='';vCroquis()}
/* medidas de un elemento frente a la fachada */
function fElDims(r,x){const T=ELT[x.tipo];const lin=T.k==='linea';const c=r.caja,cw=(c[2]-c[0])||1;const fw=(x.caja[2]-x.caja[0])/cw*(r.W||9);
  const cierre=['reja','porton','cerco','malla','muro'].includes(x.tipo);
  return{ancho:rr2(x.ancho||Math.max(.3,fw)||T.w||T.len),fondo:rr2(x.fondo||T.l||T.w||1),dist:rr2(x.distU??(cierre&&r.lado===0&&r.distReja?r.distReja:x.dist||0)),alto:x.alto||null,
    s:((x.caja[0]+x.caja[2])/2-c[0])/cw*(r.W||9)}}
/* marco de una fachada en la planta: inicio, dirección a lo largo y normal hacia afuera */
function fMarco(i,W,L){if(VV&&VV.sides?.length>i){const {pts}=vPoly();const a=pts[i],b=pts[i+1];if(a&&b){const d=Math.hypot(b[0]-a[0],b[1]-a[1])||1,u=[(b[0]-a[0])/d,(b[1]-a[1])/d];return{o:a,u,n:[u[1],-u[0]]}}}
  return[{o:[0,0],u:[1,0],n:[0,-1]},{o:[W,0],u:[0,1],n:[1,0]},{o:[W,L],u:[-1,0],n:[0,1]},{o:[0,L],u:[0,-1],n:[-1,0]}][i]}
/* convierte lo reconocido en elementos del croquis */
function fElementos(r,i,W,L){const M=fMarco(i,W,L),out=[];
  for(const x of r.els||[]){if(!x.on)continue;const T=ELT[x.tipo],D=fElDims(r,x);const off=T.k==='linea'||T.k==='punto'?D.dist:D.dist+D.fondo/2;
    const p=[M.o[0]+M.u[0]*D.s+M.n[0]*off,M.o[1]+M.u[1]*D.s+M.n[1]*off];const e=elemNew(x.tipo,p,M.u);
    if(T.k==='linea'){elSetLen(e,D.ancho);elMove(e,-(e.b[0]-e.a[0])/2*0,0);const cx=(e.a[0]+e.b[0])/2,cy=(e.a[1]+e.b[1])/2;elMove(e,p[0]-cx,p[1]-cy)}
    else if(T.k==='punto'){if(x.ancho)e.w=e.l=Math.min(D.ancho,3)}else{e.w=D.ancho;e.l=D.fondo}
    if(D.alto&&(T.k!=='area'||['terraza','escalera','rampa','jardinera'].includes(x.tipo)))e.h=D.alto;if(x.mat)e.mat=x.mat;e.det=x.det;e.src='fachada';e.fach=i;e.est=true;out.push(e)}
  return out}
const rumboTxt=h=>['norte','noreste','este','sureste','sur','suroeste','oeste','noroeste'][Math.round(((h%360)+360)%360/45)%8];

/* aplica la fachada confirmada al recorrido */
function vFachadaOk(i){const r=VV.fRes;if(!r)return;vFachadaPreview(i);
  VV.matIA=Object.assign(VV.matIA||{},Object.fromEntries(Object.entries(r.mat).filter(([,v])=>v)));if(r.techo.cubierta)VV.matIA.cubierta=r.techo.cubierta;
  if(i===0&&r.rumbo!=null)VV.norte=Math.round(r.rumbo);
  (VV.fach=VV.fach||{})[i]=true;VV.fRes=null;toast(`${FLADO[i].n} dibujada en el croquis.`);vPanel();V3.sig='';vCroquis()}

document.addEventListener('click',e=>{const b=e.target.closest('[data-vfa]');if(!b||!VV)return;const [a,x,y]=b.dataset.vfa.split(':');const r=VV.fRes;
  switch(a){
    case 'foto':vFachadaFoto(+x);break;
    case 'ok':vFachadaOk(+x);if(VV.guia)vGuiaNext();break;
    case 'van':if(r){r.vanos[+x].on=!r.vanos[+x].on;vFachadaPreview(r.lado);vPanel()}break;
    case 'add':if(r){fAddVano(r,x);vFachadaPreview(r.lado);vPanel()}break;
    case 'el':if(r){r.els[+x].on=!r.els[+x].on;vFachadaPreview(r.lado);vPanel()}break;
    case 'adde':if(r){fAddEl(r,x);vFachadaPreview(r.lado);vPanel()}break;
    case 'set':{if(!r)break;const T=VV.techo||(VV.techo={...r.techo});T[x]=y;vFachadaPreview(r.lado);vPanel();break}}});
document.addEventListener('change',e=>{const t=e.target;if(!VV||!t.dataset||!VV.fRes)return;if(t.dataset.vfan){const v=num(t.value);if(v>0){VV.fRes[t.dataset.vfan==='TH'?'TH':t.dataset.vfan]=v;vFachadaPreview(VV.fRes.lado);vPanel()}}
  if(t.dataset.vfae){const [k,campo]=t.dataset.vfae.split(':');const v=num(t.value);if(v>=0){const x=VV.fRes.els[+k];if(campo==='dist')x.distU=v;else x[campo]=v;vFachadaPreview(VV.fRes.lado);vPanel()}}
  if(t.dataset.vfav){const [k,campo]=t.dataset.vfav.split(':');const v=num(t.value);if(v>=0){const vn=VV.fRes.vanos[+k];vn.m=Object.assign(vn.m||{},{[campo]:v});vFachadaPreview(VV.fRes.lado);vPanel()}}});

/* ---------- fotos del proyecto: identificar componentes de una fachada ya fotografiada ---------- */
const FKEY=['frontal','derecha','posterior','izquierda'];
let FP=null;
async function fProyAbrir(k){const i=FKEY.indexOf(k);const ref=P.fotos[k]?.[P.fotos[k].length-1];if(i<0||!ref)return;
  FP={i,k,busy:true,res:null,T:null};fProyPinta();
  try{const blob=await (await fetch(phSrc(ref))).blob();const r=await iaFachada(blob,FLADO[i].n.toLowerCase());r.img=phSrc(ref);r.lado=i;r.DR=r.distReja||null;
    const c=P.casa;r.W=(i%2===0?+c.ancho:+c.largo)||r.ancho||(i%2===0?9:8);r.H=r.alto||+c.altura||2.4;FP.res=r;FP.T={...r.techo,tipo:r.techo.tipo||c.techo,cumbrera:r.techo.cumbrera||c.cumbrera}}
  catch(err){FP.err=iaErrorMsg(err)+(err?.message?` (${err.message})`:'')}FP.busy=false;fProyPinta()}
function fProyPinta(){let ov=$('#fov');if(!FP){ov?.remove();document.body.classList.remove('noscroll');return}
  if(!ov){ov=document.createElement('div');ov.id='fov';ov.className='fov';document.body.appendChild(ov);document.body.classList.add('noscroll')}
  const L=FLADO[FP.i];ov.innerHTML=`<div class="fovp"><div class="row sb"><h3>${esc(L.n)}: componentes</h3><button class="btn sm dark" data-pfa="cerrar" aria-label="Cerrar">✕</button></div>
    ${FP.busy?'<p class="note"><b>La IA está analizando la foto…</b> Reconoce el muro, las aguas del techo, puertas, ventanas y materiales.</p>':FP.err?`<p class="note warn">${esc(FP.err)}</p>`:fReviewHTML(FP.res,FP.T,FP.i,'pfa').replace(/<button class="btn" data-pfa="foto:\d">Otra foto<\/button>/,'')}</div>`}
function fProyOk(){const r=FP.res,i=FP.i,c=P.casa;const lado=VSIDE[i].k;
  if(i%2===0)c.ancho=rr2(r.W);else c.largo=rr2(r.W);if(!(+c.largo>0))c.largo=rr2(r.W*.8);if(!(+c.ancho>0))c.ancho=rr2(r.W);c.altura=rr2(r.H);
  const T=FP.T;if(T.tipo){c.techo=T.tipo;c.cumbrera=T.cumbrera||c.cumbrera;if(r.TH||T.alto)c.hTecho=rr2(r.TH||T.alto)}
  for(const [cat,v] of Object.entries({...r.mat,cubierta:r.techo.cubierta}))if(v&&MATS[cat]?.opts[v]&&!P.mat[cat])P.mat[cat]=v;
  P.marcas=(P.marcas||[]).filter(m=>!(m.lado===lado&&m.src==='fachada'));let n=0;
  for(const v of r.vanos){if(!v.on)continue;const M=fVanoMed(r,v);P.marcas.push({id:uid(),lado,coord:rr2(vMarkCoord({side:i,pos:M.pos},+c.ancho,+c.largo)),tipo:M.win?'ventana':'puerta',ancho:M.ancho,alto:M.alto,antepecho:M.ante,src:'fachada'});n++}
  {const W=+c.ancho,L=+c.largo;P.elementos=(P.elementos||[]).filter(e=>!(e.src==='fachada'&&e.fach===i));const ne=fElementos(r,i,W,L);P.elementos.push(...ne);n+=0;if(ne.length)toast(`${ne.length} elemento${ne.length>1?'s':''} constructivo${ne.length>1?'s':''} agregado${ne.length>1?'s':''} al terreno.`)}
  if(i===0&&r.DR)c.retiroFrontal=rr2(r.DR);
  persist();FP=null;fProyPinta();
  if(P.recintos.some(valid))placeMarks();else{render();toast(`${n} vano${n===1?'':'s'} registrado${n===1?'':'s'} en la ${FLADO[i].n.toLowerCase()}. Se ubicarán en los recintos cuando los agregues.`)}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-pfa],[data-fia]');if(!b)return;
  if(b.dataset.fia){fProyAbrir(b.dataset.fia);return}const [a,x,y]=b.dataset.pfa.split(':');if(!FP)return;const r=FP.res;
  if(a==='cerrar'){FP=null;fProyPinta()}else if(a==='van'&&r){r.vanos[+x].on=!r.vanos[+x].on;fProyPinta()}else if(a==='set'&&r){FP.T[x]=y;fProyPinta()}else if(a==='add'&&r){fAddVano(r,x);fProyPinta()}else if(a==='el'&&r){r.els[+x].on=!r.els[+x].on;fProyPinta()}else if(a==='adde'&&r){fAddEl(r,x);fProyPinta()}else if(a==='ok'&&r)fProyOk()});
document.addEventListener('change',e=>{const t=e.target;if(!FP?.res||!t.dataset)return;if(t.dataset.pfan){const v=num(t.value);if(v>0){if(t.dataset.pfan==='TH')FP.res.TH=v;else FP.res[t.dataset.pfan]=v;fProyPinta()}}
  if(t.dataset.pfae){const [k,campo]=t.dataset.pfae.split(':');const v=num(t.value);if(v>=0){const x=FP.res.els[+k];if(campo==='dist')x.distU=v;else x[campo]=v;fProyPinta()}}
  if(t.dataset.pfav){const [k,campo]=t.dataset.pfav.split(':');const v=num(t.value);if(v>=0){const vn=FP.res.vanos[+k];vn.m=Object.assign(vn.m||{},{[campo]:v});fProyPinta()}}});
